import React from "react";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard.jsx";
import Faculty from "./pages/Faculty.jsx";
import Subjects from "./pages/subjects.jsx";

const App = () => {
  return (
    <BrowserRouter>
      <Sidebar>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/Faculty" element={<Faculty />} />
          <Route path="/Subjects" element={<Subjects />} />
        </Routes>
      </Sidebar>
    </BrowserRouter>
  );
};

export default App;
